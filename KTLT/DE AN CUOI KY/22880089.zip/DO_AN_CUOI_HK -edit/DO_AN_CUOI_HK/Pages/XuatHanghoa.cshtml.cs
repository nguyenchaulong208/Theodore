using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DO_AN_CUOI_HK.Pages
{
    public class XuatHanghoaModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
