﻿namespace DO_AN_CUOI_HK.Entities
{
    
     public struct Account
     {
        public string username;
        public string password;
        public string email;

     }
}
