﻿namespace DO_AN_CUOI_HK.Entities
{
    
        public struct QL_CuaHang
        {
            public int sohoadon;
            public string ngayhoadon;
            public string ngaysanxuat;
            public string mahang;
            public string tenhang;
            public int soluong;
            public int soluongXuat;
            public int dongia;
            public int thanhtien;
            public string loaihang;
            public string nhasanxuat;
            public string hansudung;
        }
    }
