using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KTLT_SANPHAM.Pages
{
    public class MH_NhapSanPhamModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
