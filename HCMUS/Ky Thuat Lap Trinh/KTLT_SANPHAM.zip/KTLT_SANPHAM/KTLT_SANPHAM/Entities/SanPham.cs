﻿namespace KTLT_SANPHAM.Entities
{
    public struct SanPham
    {
        public string tensp;
        public string masp;
        public int gia;


    }
}
