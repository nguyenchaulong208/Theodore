﻿namespace KTLT_Buoi_3.Entities
{
    public struct SanPham
    {
        public string TenSp;
        public string MaSp;
        public int Gia;
    }
}
