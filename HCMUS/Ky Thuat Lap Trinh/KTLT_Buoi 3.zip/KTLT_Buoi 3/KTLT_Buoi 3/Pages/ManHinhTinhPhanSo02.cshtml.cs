using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KTLT_Buoi_3.Pages
{
    public class ManHinhTinhPhanSo02Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
