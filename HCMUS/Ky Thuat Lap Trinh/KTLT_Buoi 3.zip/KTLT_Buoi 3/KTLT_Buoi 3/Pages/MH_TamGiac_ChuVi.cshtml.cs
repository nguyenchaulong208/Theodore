using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KTLT_Buoi_3.Pages
{
    public class MH_TamGiac_ChuViModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
