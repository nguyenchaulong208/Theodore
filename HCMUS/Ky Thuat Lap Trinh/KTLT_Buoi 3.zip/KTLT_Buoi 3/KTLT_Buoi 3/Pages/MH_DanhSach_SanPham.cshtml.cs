using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KTLT_Buoi_3.Pages
{
    public class MH_DanhSach_SanPhamModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
