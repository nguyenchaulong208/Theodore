Họ và tên: Nguyễn Châu Long
Mã số sinh viên: 22880089

Các chức năng đã thực hiện:


Các chức năng chưa thực hiện:



Các chức năng giáo viên nên xem xét cộng điểm vì đã bỏ nhiều thời gian và công sức tìm hiểu:





Điểm tự đánh giá:



Link video: