Họ và tên: Nguyễn Châu Long
Mã số sinh viên: 22880089

Các chức năng đã thực hiện:
-Thêm xóa sửa danh mục hàng hóa
-Thêm xóa sửa danh sách phiếu nhập
-Thêm xóa sửa danh sách phiếu xuất
- tổng hợp phiếu xuất
- tổng hợp danh mục hàng hóa
- tổng hợp phiếu nhập
- tổng hợp phiếu xuất
- tổng hợp mã hàng hóa đã tạo
- filter danh mục
- sắp xếp các dữ liệu trong bảng theo thứ tự tăng dần
- export excel
- login
- mã hóa tài khoản đăng nhập
- kết nối database

Các chức năng chưa thực hiện:



Các chức năng giáo viên nên xem xét cộng điểm vì đã bỏ nhiều thời gian và công sức tìm hiểu:





Điểm tự đánh giá: 10
