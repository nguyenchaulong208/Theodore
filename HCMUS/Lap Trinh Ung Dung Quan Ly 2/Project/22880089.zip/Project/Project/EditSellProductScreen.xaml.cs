﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project
{
    /// <summary>
    /// Interaction logic for EditSellProductScreen.xaml
    /// </summary>
    public partial class EditSellProductScreen : Window
    {
        private readonly int selectedSellItem;
        public EditSellProductScreen(int _sellItem)
        {
            InitializeComponent();
            selectedSellItem = _sellItem;
            MS getSellItems = new MS();

            // Gán dữ liệu từ SellItem vào các control
            InvoiceDatePicker.Text = getSellItems.GetDatabase("order_invoice_date", "order_item", "order_item_id", selectedSellItem);
           string selectedBrand = getSellItems.GetDatabase("order_item_brand", "order_item", "order_item_id", selectedSellItem);
            editBrandComboBox.SelectedItem = getSellItems.GetDatabase("category_name", "category", "category_id", Convert.ToInt32(selectedBrand));

            // Tạo danh sách sản phẩm tạm thời từ SellItem để hiển thị trên DataGrid
           // editProductSell.ItemsSource = new List<SellItem> { selectedSellItem };

        }

        private void SaveEditSell_Click(object sender, RoutedEventArgs e)
        {
            // Lấy thông tin từ form và gán lại vào selectedSellItem
            //selectedSellItem.SellInvoiceDate = InvoiceDatePicker.Text;
            //if (BrandComboBox.SelectedItem is int selectedBrand)
            //{
            //    selectedSellItem.SellBrand = selectedBrand;
            //}

            //// Lấy thông tin từ DataGrid
            //if (editProductSell.ItemsSource is IEnumerable<SellItem> editedItems)
            //{
            //    var updatedItem = editedItems.FirstOrDefault(); // Vì danh sách này chỉ chứa 1 item
            //    if (updatedItem != null)
            //    {
            //        selectedSellItem.SellQuantity = updatedItem.SellQuantity;
            //        selectedSellItem.SellPrice = updatedItem.SellPrice;
            //        selectedSellItem.SellTotal = updatedItem.SellTotal;
            //    }
            //}

            //// Đóng cửa sổ
            //MessageBox.Show("Dữ liệu đã được lưu thành công.", "Thông báo", MessageBoxButton.OK, MessageBoxImage.Information);
            //this.DialogResult = true; // Để biết rằng người dùng đã lưu
            //this.Close();
        }

        private void CancelEditSell_Click(object sender, RoutedEventArgs e)
        {

        }

        private void searchProduct(object sender, KeyEventArgs e)
        {

        }
    }
}
