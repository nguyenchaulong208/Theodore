document.addEventListener("DOMContentLoaded", () => {
  console.log("Simple Threads - Static Site Loaded");
});
