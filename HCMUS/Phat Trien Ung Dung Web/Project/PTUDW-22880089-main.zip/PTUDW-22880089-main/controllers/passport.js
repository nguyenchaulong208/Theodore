'use strict';

const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcryptjs');
const models = require('../models');

// ham nay duoc goi khi xac thuc thanh cong va luu thong tin user vao session
passport.serializeUser((user, done) => {
	done(null, user.id);
});

// ham goi boi passport.session de lay thong tin cua user tu csdl dua vao req.user
passport.deserializeUser(async (id, done) => {
	try {
		let user = await models.User.findOne({
			attributes: [ 'id', 'email', 'firstName', 'lastName', 'mobile', 'isAdmin' ],
			where: { id }
		});
		done(null, user);
	} catch (error) {
		done(error);
	}
});

// ham xac thuc nguoi dung khi dang nhap

passport.use(
	'local-login',
	new LocalStrategy(
		{
			usernameField: 'email', // trường email dùng để đăng nhập
			passwordField: 'password', // trường password
			passReqToCallback: true // cho phép truyền req vào callback
		},
		async (req, email, password, done) => {
			
			if (email) {
				email = email.toLowerCase();
			}

			try { 
				if (!req.user) {
					// neu user chua dang nhap
					let user = await models.User.findOne({
						where: { email }
					});
					if (!user) {
						return done(null, false, req.flash('loginMessage', 'Email does not exist'));
					}

					// console.log('Password nhập vào:', password);  
					// console.log('Password trong DB:', user.password);  
					
					const compareResult = bcrypt.compare(password, user.password); 
					// console.log('Kết quả so sánh:', compareResult);
					if (!compareResult) {
						// neu mat khau khong dung
						return done(null, false, req.flash('loginMessage', 'Invalid Password'));
					}
					// cho phep dang nhat
					return done(null, user);
				}
				// Bỏ qua đăng nhập nếu đã có user
				done(null, req.user);
			} catch (error) {
				return done(error);
			}
		}
	)
);

// dang ky tao khoan
passport.use('local-register', new LocalStrategy({  
    usernameField: 'email',  
    passwordField: 'password',  
    passReqToCallback: true  
}, async (req, email, password, done) => {  
    try {  
        // Chuyển email về lowercase  
        if (email) {  
            email = email.toLowerCase();  
        }  

        // Kiểm tra nếu user đã đăng nhập thì bỏ qua  
        if (req.user) {  
            return done(null, req.user);  
        }  

        // Kiểm tra email đã tồn tại chưa  
        let user = await models.User.findOne({   
            where: { email }  
        });  

        if (user) {  
            return done(null, false, req.flash('registerMessage', 'Email is already taken!'));  
        }  

        // Tạo user mới  
        user = await models.User.create({  
            email: email,  
            password: bcrypt.hashSync(password, bcrypt.genSaltSync(8)),  
            firstName: req.body.firstName,  
            lastName: req.body.lastName,   
            mobile: req.body.mobile  
        });  

        // Trả về user mới tạo  
        done(null, false, req.flash('registerMessage', 'You have Register successfully. Please login!'));  

    } catch (error) {  
        done(error);  
    }  
}));  


module.exports = passport;
