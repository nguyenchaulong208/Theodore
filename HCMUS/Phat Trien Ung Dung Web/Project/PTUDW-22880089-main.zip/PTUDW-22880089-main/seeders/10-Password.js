'use strict';

const { update } = require('../controllers/cartController');

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        const models = require('../models');
        const bcrypt = require('bcryptjs');
        
        // update hash password
        let users = await models.User.findAll();
        let updatedUsers = [];
        users.forEach(item => {  
            updatedUsers.push({  
                id: item.id,  
                // Tạo hash password mới với salt rounds = 8  
                password: bcrypt.hashSync("Demo@123", 8)  
            });  
        }); 
        await models.User.bulkCreate(updatedUsers, {  
            updateOnDuplicate: ['password']  // Chỉ update trường password  
        }); 
        
    },

    async down(queryInterface, Sequelize) {

    }
};
